﻿CREATE DATABASE CooFood;

use QLDA

CREATE TABLE KhachHang (
   KhachHangID INT PRIMARY KEY,
   HovaTen NVARCHAR(50),
   DiaChi NVARCHAR(100),
   SoDienThoai NVARCHAR(20)
);

CREATE TABLE HoaDon (
    HoaDonID INT PRIMARY KEY,
    NgayLap DATE NOT NULL
);
CREATE TABLE NhanVien (
    NhanVienID INT PRIMARY KEY,
    DiaChi NVARCHAR(100) NOT NULL,
    SoDienThoai NVARCHAR(20) NOT NULL
);
CREATE TABLE PhieuNhapHang (
    MaPN INT PRIMARY KEY,
    NgayNhap DATE NOT NULL,
    NhanVienID INT,
    FOREIGN KEY (NhanVienID) REFERENCES NhanVien(NhanVienID)
);
CREATE TABLE CTPhieuNhap (
    CTPPHID INT PRIMARY KEY,
    MaPN INT,
    SoLuong INT,
    Gia FLOAT,
    FOREIGN KEY (MaPN) REFERENCES PhieuNhapHang(MaPN)
);
CREATE TABLE PhieuXuatHang (
    MaPX INT PRIMARY KEY,
    NgayXuat DATE NOT NULL,
    NhanVienID INT,
    FOREIGN KEY (NhanVienID) REFERENCES NhanVien(NhanVienID)
);
CREATE TABLE CTPhieuXuat (
    CTXHID INT PRIMARY KEY,
    MaPX INT,
    SoLuong INT,
    Gia FLOAT,
    FOREIGN KEY (MaPX) REFERENCES PhieuXuatHang(MaPX)
);
CREATE TABLE MatHang (
    MatHangID INT PRIMARY KEY,
    TenMatHang NVARCHAR(100) NOT NULL,
    HangSX NVARCHAR(50) NOT NULL,
    NgaySX DATE NOT NULL,
    GiaBan MONEY NOT NULL,
    KhachHangID INT,
    HoaDonID INT,
    MaPN INT,
    MaPX INT,
    FOREIGN KEY (KhachHangID) REFERENCES KhachHang(KhachHangID),
    FOREIGN KEY (HoaDonID) REFERENCES HoaDon(HoaDonID),
    FOREIGN KEY (MaPN) REFERENCES PhieuNhapHang(MaPN),
    FOREIGN KEY (MaPX) REFERENCES PhieuXuatHang(MaPX)
);
CREATE TABLE CTHD (
    CTHDID INT PRIMARY KEY,
    HoaDonID INT,
    SoLuong INT,
    GiaBan FLOAT,
    MatHangID INT,
    FOREIGN KEY (HoaDonID) REFERENCES HoaDon(HoaDonID),
    FOREIGN KEY (MatHangID) REFERENCES MatHang(MatHangID)
);
INSERT INTO KhachHang (KhachHangID, HovaTen, DiaChi, SoDienThoai)
VALUES (1, 'Tran Van B', '456 Nguyen Hue, Quan 1, TP. Ho Chi Minh', '0902345678'),
       (2, 'Le Thi C', '789 Le Lai, Quan 3, TP. Ho Chi Minh', '0903456789'),
       (3, 'Pham Van D', '101 Nguyen Van Cu, Quan 5, TP. Ho Chi Minh', '0904567890'),
       (4, 'Nguyen Thi E', '246 Ly Thuong Kiet, Quan 10, TP. Ho Chi Minh', '0905678901'),
       (5, 'Truong Van F', '369 Vo Van Tan, Quan 3, TP. Ho Chi Minh', '0906789012');
	   
INSERT INTO HoaDon (HoaDonID,NgayLap) VALUES (1,'2022-04-18'), (2,'2022-04-19'), (3,'2022-04-20');

INSERT INTO NhanVien (NhanVienID, DiaChi, SoDienThoai)
VALUES 
    (1, 'Số 1 Đại Cồ Việt, Hai Bà Trưng, Hà Nội', '0987654321'),
    (2, 'Số 2 Trần Hưng Đạo, Hoàn Kiếm, Hà Nội', '0987654322'),
    (3, 'Số 3 Nguyễn Công Trứ, Hoàn Kiếm, Hà Nội', '0987654323'),
    (4, 'Số 4 Bà Triệu, Hai Bà Trưng, Hà Nội', '0987654324'),
    (5, 'Số 5 Lê Thánh Tông, Hoàn Kiếm, Hà Nội', '0987654325');

INSERT INTO PhieuNhapHang (MaPN, NgayNhap, NhanVienID)
VALUES 
    (1, '2022-01-01', 1),
    (2, '2022-01-02', 2),
    (3, '2022-01-03', 3),
    (4, '2022-01-04', 4),
    (5, '2022-01-05', 5);
							
INSERT INTO CTPhieuNhap (CTPPHID, MaPN, SoLuong, Gia)
VALUES 
    (1, 1, 10, 1000.0),
    (2, 1, 15, 1500.0),
    (3, 2, 20, 2000.0),
    (4, 3, 25, 2500.0),
    (5, 4, 30, 3000.0);
INSERT INTO PhieuXuatHang (MaPX, NgayXuat, NhanVienID)
VALUES 
    (1, '2023-04-15', 1),
    (2, '2023-04-16', 2),
    (3, '2023-04-17', 3),
    (4, '2023-04-18', 1),
    (5, '2023-04-19', 2);
INSERT INTO CTPhieuXuat (CTXHID, MaPX, SoLuong, Gia)
VALUES 
    (1, 1, 5, 100000),
    (2, 2, 10, 50000),
    (3, 3, 3, 120000),
    (4, 4, 7, 80000),
    (5, 5, 2, 150000);
INSERT INTO MatHang (MatHangID, TenMatHang, HangSX, NgaySX, GiaBan, KhachHangID, HoaDonID, MaPN, MaPX) 
VALUES 
(1, 'Áo thun nam', 'N/A', '2022-01-15', 150000, 2, 1, NULL, NULL),
(2, 'Quần jean nữ', 'ABC', '2021-12-01', 300000, NULL, 1, NULL, 1),
(3, 'Dép xỏ ngón', 'XYZ', '2022-03-20', 80000, NULL, NULL, 2, NULL),
(4, 'Balo học sinh', 'DEF', '2022-02-10', 250000, 3, 2, NULL, NULL),
(5, 'Giày thể thao', 'MNO', '2022-04-05', 500000, NULL, NULL, 3, 2);

);
INSERT INTO CTHD (CTHDID, HoaDonID, SoLuong, GiaBan, MatHangID)
VALUES (1, 1, 2, 150000, 1),
       (2, 2, 1, 300000, 2),
       (3, 3, 3, 100000, 3);
CREATE PROCEDURE AddNewCustomer
@KhachHangID INT,
@HovaTen NVARCHAR(100),
@DiaChi NVARCHAR(255),
@SoDienThoai NVARCHAR(15)
AS
BEGIN
    INSERT INTO KhachHang (KhachHangID, HovaTen, DiaChi, SoDienThoai)
    VALUES (@KhachHangID, @HovaTen, @DiaChi, @SoDienThoai)
END
EXEC AddNewCustomer @KhachhangID = 6, @Hovaten= 'Nguyen Van A' , @Diachi = '123 Nguyen Hue, Quan 1, TP HCM', @SoDienThoai = '03557780555'

CREATE PROCEDURE AddNewProduct
@MatHangID INT,
@TenMatHang NVARCHAR(100),
@HangSX NVARCHAR(100),
@NgaySX DATE,
@GiaBan DECIMAL(18, 2)
AS
BEGIN
    INSERT INTO MatHang (MatHangID, TenMatHang, HangSX, NgaySX, GiaBan)
    VALUES (@MatHangID, @TenMatHang, @HangSX, @NgaySX, @GiaBan)
END
EXEC AddNewProduct
@MatHangID = 6,
@TenMatHang = 'product B',
@HangSX = '	Brand X',
@NgaySX = '2022-01-01',
@GiaBan = 100.00
SELECT * FROM  MatHang WHERE @MatHangID = 6
CREATE PROCEDURE GenerateNewInvoice
@HoaDonID INT,
@NgayLap DATE
AS
BEGIN
    INSERT INTO HoaDon (HoaDonID, NgayLap)
    VALUES (@HoaDonID, @NgayLap)
END

EXEC GenerateNewInvoice @HoaDonID = 123456, @NgayLap = '2022-05-02';

CREATE PROCEDURE AddItemToInvoice
@HoaDonID INT,
@MatHangID INT,
@SoLuong INT,
@GiaBan DECIMAL(18, 2)
AS
BEGIN
    INSERT INTO CTHD (HoaDonID, MatHangID, SoLuong, GiaBan)
    VALUES (@HoaDonID, @MatHangID, @SoLuong, @GiaBan)
END
EXEC AddItemToInvoice @HoaDon = 1, @NgayLap = '2022-05-02';

CREATE PROCEDURE GetTotalSales
@FromDate DATE,
@ToDate DATE
AS
BEGIN
    SELECT SUM(CTHD.SoLuong * CTHD.GiaBan) AS TotalSales
    FROM CTHD
    JOIN HoaDon ON CTHD.HoaDonID = HoaDon.HoaDonID
    WHERE HoaDon.NgayLap BETWEEN @FromDate AND @ToDate
END
EXEC GetTotalSales @FromDate = '2022-01-01', @ToDate = '2022-12-31';

CREATE FUNCTION fn_TongGiaTriHoaDon()
RETURNS FLOAT
AS
BEGIN
    DECLARE @TongGia FLOAT;
    SELECT @TongGia = SUM(SoLuong * GiaBan)
    FROM CTHD;
    RETURN @TongGia;
END
GO
SELECT dbo.fn_TongGiaTriHoaDon() AS TongGiaTri;
CREATE FUNCTION fn_GetMatHangByDateRange (@FromDate DATE, @ToDate DATE)
RETURNS TABLE
AS
RETURN
    SELECT * FROM MatHang
    WHERE NgaySX >= @FromDate AND NgaySX <= @ToDate
GO
SELECT * FROM fn_GetMatHangByDateRange('2022-01-15','2022-12-31');
CREATE FUNCTION fn_TongSoLuongMatHangXuatTheoNhanVien ()
RETURNS TABLE
AS
RETURN
    SELECT CTXHID, SUM(SoLuong) AS TongSoLuongXuat
    FROM CTPhieuXuat
    GROUP BY CTXHID
GO
SELECT * FROM dbo.fn_TongSoLuongMatHangXuatTheoNhanVien()
CREATE FUNCTION fn_GetHoaDonByDateRange (@FromDate DATE, @ToDate DATE)
RETURNS TABLE
AS
RETURN
    SELECT * FROM HoaDon
    WHERE NgayLap >= @FromDate AND NgayLap <= @ToDate
GO
SELECT * FROM dbo.fn_GetHoaDonByDateRange('2022-01-01', '2022-12-31');

CREATE TRIGGER trg_InsertCTPN
AFTER INSERT ON HoaDon
FOR EACH ROW
BEGIN
    INSERT INTO CTPhieuNhap(MaPN, SoLuong, Gia)
    VALUES(NEW.HoaDonID, 0, 0);
END;
CREATE TRIGGER trg_UpdateCTPN
AFTER UPDATE ON MatHang
FOR EACH ROW
BEGIN
    UPDATE CTPhieuNhap
    SET SoLuong = NEW.SoLuong, Gia = NEW.GiaBan
    WHERE MaPN = NEW.MaPN AND MatHangID = NEW.MatHangID;
END;
CREATE TRIGGER trg_UpdateCTPN
AFTER UPDATE ON MatHang
FOR EACH ROW
BEGIN
    UPDATE CTPhieuNhap
    SET SoLuong = NEW.SoLuong, Gia = NEW.GiaBan
    WHERE MaPN = NEW.MaPN AND MatHangID = NEW.MatHangID;
END;

CREATE TRIGGER trg_UpdateNgaySX
AFTER INSERT ON PhieuNhapHang
FOR EACH ROW
BEGIN
    UPDATE MatHang
    SET NgaySX = NEW.NgayNhap
    WHERE MatHangID = NEW.MaPN;
END;
CREATE TRIGGER trg_UpdateGiaBan
AFTER UPDATE ON MatHang
FOR EACH ROW
BEGIN
    IF NEW.GiaBan > OLD.GiaBan THEN
        UPDATE HoaDon
        SET GiaBan = NEW.GiaBan
        WHERE MatHangID = NEW.MatHangID;
        UPDATE CTPhieuNhap
        SET Gia = NEW.GiaBan
        WHERE MatHangID = NEW.MatHangID;
    END IF;
END;

UPDATE KhachHang
SET HovaTen = N'Nguyen Van A' 
WHERE KhachHangID = '2' ;
UPDATE MatHang
SET DiaChi = '428 Mã Lò Phường Bình Hưng Hòa A Quận Bình Tân' 
WHERE NhanVienID = 2;
UPDATE MatHang
SET TenMatHang = 'Dép Lào', GiaBan = '15000,000' 
WHERE MatHangID = 3;